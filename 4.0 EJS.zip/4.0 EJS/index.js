import express from "express";
import ejs from "ejs";

const app = express();
const port = 3000;

app.get("/",(req,res)=>{
    const d = new Date("June 24, 2023 11:30:00");
    const day = d.getDay();

    let type = "a weekday";
    let adv = "Its time to work hard.";

    if(day === 0 || day=== 6){
        type = "the weekend";
        adv = "It's time to enjoy.";
    }

    res.render("index.ejs",{
        dayType : type,
        advice : adv,
    })
});

app.listen(port,()=>{
    console.log(`Listening to port ${port}`);
});

