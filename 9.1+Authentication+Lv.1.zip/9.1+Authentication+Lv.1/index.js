import express from "express";
import bodyParser from "body-parser";
import pg from "pg";

const app = express();
const port = 3000;
const db = new pg.Client({
  user : "postgres",
  host : "localhost",
  database : "Authentication",
  password : "rahul5710",
  port : 5432
})
db.connect();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.render("home.ejs");
});

app.get("/login", (req, res) => {
  res.render("login.ejs");
});

app.get("/register", (req, res) => {
  res.render("register.ejs");
});

app.post("/register", async (req, res) => {
  console.log(req.body.username);
  console.log(req.body.password);
  try{
    await db.query("INSERT INTO users(email,password) VALUES ($1,$2)",[req.body.username,req.body.password]);
    res.render("home.ejs",{
      popup : 1,
    });
  }catch(err){
    console.log(err);
    res.render("home.ejs",{
      popup : 2,
    });
  }
});

app.post("/login", async (req, res) => {
  console.log(req.body.username);
  console.log(req.body.password);
  try{
    const info = await db.query("SELECT * FROM users WHERE email=$1",[req.body.username]);
    if(info.rows.length!=0){
      const pass = info.rows[0].password;
      console.log(pass);
      if(pass==req.body.password){
        res.render("secrets.ejs");
      }else{
        res.render("home.ejs",{
          popup : 3,
        });
      }
    }else{
      res.render("home.ejs",{
      popup : 4,
      });
    }
    
  }catch(err){
    console.log(err);
  }
  
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
