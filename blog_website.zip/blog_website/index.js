import express from "express";
import bodyParser from "body-parser";

let count=1;
let count1 = 1;
var title=[];
var Blog=[];
var name=[];
var email=[];
var comment=[];
const app = express();
const port = 3000;

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended : true}));

app.get("/",(req,res)=>{
    res.render("index.ejs");
});

app.get("/create",(req,res)=>{
    res.render("createblog.ejs");
})

app.post("/save",(req,res)=>{
    console.log(req.body)
    if(req.body["t"]!='')
    {
        title[count]=req.body["t"];
        Blog[count]=req.body["blog"];
        count=count+1;
    }
    res.render("createblog.ejs");
})

app.get("/contact",(req,res)=>{
    res.render("contact.ejs");
})

app.get("/view",(req,res)=>{
    res.render("viewblog.ejs",res.locals={
        t : title,
        blog : Blog,
        c : count,
        d : count
      })
})

app.post("/send",(req,res)=>{
    console.log(req.body);
    if(req.body["name"]!='')
    {
        name[count1]=req.body["name"];
        email[count1]=req.body["email"];
        comment[count1]=req.body["comment"];
        count1=count1+1;
    }
    res.render("contact.ejs");
})

app.get("/responce",(req,res)=>{
    console.log(name);
    console.log(email);
    console.log(comment);
    res.render("responce.ejs",res.locals={
        n : name,
        e : email,
        k : comment,
        m : count1
    })
})

app.use(express.json());
app.post("/Delete",(req,res)=>{
    const {buttonId} = req.body
    console.log(title)
    console.log(Blog)
    console.log(buttonId)
    title.splice(buttonId,1)
    Blog.splice(buttonId,1)
    count=count-1
    console.log(title)
    console.log(Blog)
    console.log(count)
    res.render("viewblog.ejs",res.locals={
        t : title,
        blog : Blog,
        c : count,
        d : count
    })
})

app.post("/edit",(req,res)=>{
    const {editNO} = req.body;
    res.render("createblog.ejs",res.locals={
        nt : title[editNO],
        nb : Blog[editNO]
    });
    title.splice(editNO,1)
    Blog.splice(editNO,1)
    count=count-1
})

app.listen(port,()=>{
    console.log(`Listening to port ${port}.`)
})
