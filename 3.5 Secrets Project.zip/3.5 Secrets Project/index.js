//To see how the final website should work, run "node solution.js".
//Make sure you have installed all the dependencies with "npm i".
//The password is ILoveProgramming

/*
My logic =>

import express from "express";
import bodyParser from "body-parser";
import {dirname} from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

const app=express();
const port = 3000;
var ans;

app.use(bodyParser.urlencoded({extended : true}));

function passwordChecker(req,res,next){
    console.log(req.body["password"]);
    if(req.body["password"] == "iLoveProgramming")
    {
        res.sendFile(__dirname + "/public/secret.html");
    }
    else{
        res.send("<h1>wrong password.</h1>");
    }
}

app.use(passwordChecker);

app.get("/",(req,res)=>{
    res.sendFile(__dirname + "/public/index.html");
});


app.listen(port,()=>{
    console.log(`listening to port ${port}`);
});
*/

import express from "express";
import bodyParser from "body-parser";
import {dirname} from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

const app=express();
const port = 3000;
var ans=false;

app.use(bodyParser.urlencoded({extended : true}));

function passwordChecker(req,res,next){
    console.log(req.body["password"]);
    if(req.body["password"] === "iLoveProgramming")
    {
        ans=true;
    }
    next();
}

app.use(passwordChecker);

app.get("/",(req,res)=>{
    res.sendFile(__dirname + "/public/index.html");
});

app.post("/check",(req,res)=>{
    if(ans===true){
        res.sendFile(__dirname + "/public/secret.html");
    }
    else{
        res.sendFile(__dirname + "/public/index.html");
    }
});

app.listen(port,()=>{
    console.log(`listening to port ${port}`);
});