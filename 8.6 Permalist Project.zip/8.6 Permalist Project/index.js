import express from "express";
import bodyParser from "body-parser";
import pg from "pg"

const app = express();
const port = 3000;

const db=new pg.Client({
  user : "postgres",
  host : "localhost",
  database : "permalist",
  password : "rahul5710",
  port : 5432
})

db.connect();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

let items = [
  { id: 1, title: "Buy milk" },
  { id: 2, title: "Finish homework" },
];

async function opener(){
  const items = await db.query("SELECT * FROM information");
  console.log(items.rows)
  return items.rows;
}

app.get("/", async (req, res) => {
  const items = await opener();
  res.render("index.ejs", {
    listTitle: "Today",
    listItems: items,
  });
});

app.post("/add", (req, res) => {
  const item = req.body.newItem;
  console.log(item);
  db.query("INSERT INTO information(title) VALUES($1)",[item])
  res.redirect("/");
});

app.post("/edit", async(req, res) => {
  console.log(req.body.updatedItemTitle);
  const updatedItemTitle = req.body.updatedItemTitle;
  const updatedItemId = req.body.updatedItemId;
  await db.query("UPDATE information SET title=$1 WHERE id=$2",[updatedItemTitle,updatedItemId])
  res.redirect("/");
});

app.post("/delete",async (req, res) => {
  console.log(req.body);
  await db.query("DELETE FROM information WHERE id=$1",[req.body.deleteItemId]);
  res.redirect("/");
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
